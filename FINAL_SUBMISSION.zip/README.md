# TaskManager Project (Submission-ready)

**Submitted by:** Aadya

## Setup Instructions

1. Create a Python virtual environment and activate it:
```bash
python -m venv venv
# Windows
venv\Scripts\activate
# macOS / Linux
source venv/bin/activate
```

2. Install dependencies:
```bash
pip install -r requirements.txt
```
If you prefer, install minimal dependencies directly:
```bash
pip install django djangorestframework
```

3. Apply database migrations:
```bash
python manage.py migrate
```

4. Run the development server:
```bash
python manage.py runserver
```

5. Open the API endpoint in your browser:
```
http://127.0.0.1:8000/api/tasks/
```

6. Run tests:
```bash
python manage.py test
```

---

## Algorithm Explanation (Priority Scoring) — ~350 words

The project's priority scoring algorithm is implemented in `tasks/scoring.py`. It converts task metadata (importance, estimated hours/effort, due date, and dependency relationships) into a single normalized priority score (0–100). The algorithm is intentionally modular and interpretable, composed of these key steps:

1. **Sanitization** — Each task is normalized with default values to ensure stable scoring: default importance (5), default estimated hours (1.0), empty dependencies list, and optional due date parsing.

2. **Normalization** — Raw task attributes are converted into normalized factors in the range \[0,1\]:
   - *Importance* uses a scale mapping (e.g., 1–10 mapped to 0–1) so that relative priority differences remain meaningful.
   - *Effort* (estimated hours) is normalized inversely: tasks requiring less time score higher under "fast" modes, and higher effort reduces the normalized effort value.
   - *Deadline/Urgency* is a normalized function of days remaining (or past due values). Nearer or past due dates increase urgency.
   - *Blocked count* captures how many other tasks depend on a given task (i.e., how “blocking” it is). This is normalized against the maximum blocked count to form a blocker factor.

3. **Dependency & Cycle Handling** — The algorithm detects dependency cycles using DFS. Cyclic tasks are reported separately (so they can be inspected), and a dependency penalty reduces a task’s raw score if it relies on many other tasks (encouraging focus on independent, actionable items).

4. **Weighted Scoring** — Multiple weight sets (`WEIGHT_SETS`) are provided for different prioritization strategies (e.g., `smart`, `fastest`, `impact`, `deadline`). The final raw score is a weighted sum of the normalized factors:
```
raw = w_importance*importance_n + w_urgency*urgency_n + w_effort*effort_n + w_deadline*urgency_n
```
A blocker bonus is then added to reward tasks that unblock many others. The final score is scaled to 0–100 and rounded.

5. **Output** — The function `score_tasks(tasks, mode='smart')` returns a dict containing `tasks_sorted` (non-cyclic tasks sorted by priority score), `cycles` (list of dependency cycles), and `cyclic_tasks`.

This approach balances interpretability and flexibility: by swapping weight sets or adjusting normalization functions, the system supports different prioritization philosophies while remaining transparent about why a task scored as it did.

---

## Design Decisions & Trade-offs

- **Interpretable weights**: Chosen for explainability over black-box ML models. Easier to debug and justify.
- **Multiple modes**: `WEIGHT_SETS` allow quick switching between strategies (speed vs impact).
- **Cycle detection**: Cycles are surfaced instead of silently breaking, enabling users to fix data issues.
- **Simplicity over perfection**: Normalizations are heuristic-driven for reliability without heavy maintenance.

---

## Time Breakdown (approx)
- Code review & polishing: 1.5 hours  
- Writing README + explanations: 1 hour  
- Adding unit tests: 1 hour  
- Packaging & checks: 0.5 hours  
**Total:** ~4 hours

---

## Bonus Challenges Attempted
- Added unit tests for the scoring algorithm and cycle detection.
- Created a clear README and requirements file.

---

## Future Improvements
- Add frontend visual explanation (why a task scored X) using score_reason.
- Allow user-defined custom weight profiles through the UI.
- Add integration tests and CI pipeline (GitHub Actions).
- Persist scoring mode history and allow re-scoring experiments.

