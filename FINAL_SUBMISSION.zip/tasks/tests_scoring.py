from django.test import TestCase
from tasks import scoring
from datetime import date, timedelta

class ScoringUnitTests(TestCase):
    def test_higher_importance_increases_score(self):
        t1 = {'id':1, 'title':'low', 'importance':1, 'estimated_hours':1, 'due_date':None, 'dependencies':[]}
        t2 = {'id':2, 'title':'high', 'importance':10, 'estimated_hours':1, 'due_date':None, 'dependencies':[]}
        res = scoring.score_tasks([t1,t2], mode='impact')
        s1 = next(t for t in res['tasks_sorted'] if t['id']==1)['priority_score']
        s2 = next(t for t in res['tasks_sorted'] if t['id']==2)['priority_score']
        self.assertTrue(s2 > s1, "Higher importance should yield higher score")

    def test_blocker_bonus_applies(self):
        # Task 1 blocks task 2 and 3
        t1 = {'id':1, 'title':'blocker', 'importance':5, 'estimated_hours':1, 'due_date':None, 'dependencies':[]}
        t2 = {'id':2, 'title':'child1', 'importance':3, 'estimated_hours':1, 'due_date':None, 'dependencies':[1]}
        t3 = {'id':3, 'title':'child2', 'importance':2, 'estimated_hours':1, 'due_date':None, 'dependencies':[1]}
        res = scoring.score_tasks([t1,t2,t3], mode='smart')
        # blocker should have non-zero blocked count and thus a blocker bonus
        blocker = next(t for t in res['tasks_sorted'] if t['id']==1)
        self.assertTrue(blocker['priority_score'] >= 0)

    def test_cycle_detection_reports_cycle(self):
        # 1 -> 2 -> 3 -> 1 (cycle)
        t1 = {'id':1,'title':'a','importance':5,'estimated_hours':1,'due_date':None,'dependencies':[2]}
        t2 = {'id':2,'title':'b','importance':5,'estimated_hours':1,'due_date':None,'dependencies':[3]}
        t3 = {'id':3,'title':'c','importance':5,'estimated_hours':1,'due_date':None,'dependencies':[1]}
        res = scoring.score_tasks([t1,t2,t3])
        self.assertTrue(len(res['cycles']) > 0)
        self.assertTrue(len(res['cyclic_tasks']) == 3)
