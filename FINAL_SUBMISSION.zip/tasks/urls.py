# from django.urls import path
# from .views import AnalyzeTasksView, SuggestTasksView

# urlpatterns = [
#     path('analyze/', AnalyzeTasksView.as_view(), name='analyze-tasks'),
#     path('suggest/', SuggestTasksView.as_view(), name='suggest-tasks'),
# ]


from django.urls import path
from .views import TaskListCreateView

urlpatterns = [
    path('', TaskListCreateView.as_view(), name='task-list'),
]
