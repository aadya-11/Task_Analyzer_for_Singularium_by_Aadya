# from django.shortcuts import render

# # Create your views here.
# from rest_framework.views import APIView
# from rest_framework.response import Response
# from rest_framework import status
# from .scoring import score_tasks
# from .models import Task
# from .serializers import TaskSerializer

# class AnalyzeTasksView(APIView):
#     def post(self, request):
#         mode = request.query_params.get('mode', 'smart')
#         tasks = request.data if isinstance(request.data, list) else request.data.get('tasks', [])
#         if not isinstance(tasks, list):
#             return Response({"detail":"Invalid payload; expected list of tasks"}, status=status.HTTP_400_BAD_REQUEST)
#         next_temp_id = -1
#         for t in tasks:
#             if 'id' not in t or t['id'] is None:
#                 t['id'] = next_temp_id
#                 next_temp_id -= 1
#         result = score_tasks(tasks, mode=mode)
#         return Response(result, status=status.HTTP_200_OK)

# class SuggestTasksView(APIView):
#     def get(self, request):
#         mode = request.query_params.get('mode', 'smart')
#         qs = Task.objects.all()
#         serializer = TaskSerializer(qs, many=True)
#         tasks = serializer.data
#         for t in tasks:
#             t['id'] = int(t['id'])
#             t.setdefault('estimated_hours', 1.0)
#             t.setdefault('importance', 5)
#             t.setdefault('dependencies', [])
#         result = score_tasks(tasks, mode=mode)
#         top3 = result['tasks_sorted'][:3]
#         suggestions = []
#         for t in top3:
#             reason = t.get('score_reason', {})
#             explanation = (
#                 f"Score={t['priority_score']}. Importance={reason.get('importance_n')}, "
#                 f"Urgency={reason.get('urgency_n')}, Effort={reason.get('effort_n')}, "
#                 f"BlocksOthers={reason.get('blocked_n')}"
#             )
#             suggestions.append({"task": t, "explanation": explanation})
#         return Response({"suggestions": suggestions, "cycles": result['cycles']}, status=status.HTTP_200_OK)



from rest_framework import generics
from .models import Task
from .serializers import TaskSerializer

class TaskListCreateView(generics.ListCreateAPIView):
    queryset = Task.objects.all()
    serializer_class = TaskSerializer
