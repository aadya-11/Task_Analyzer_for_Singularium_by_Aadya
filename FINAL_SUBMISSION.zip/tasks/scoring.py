from datetime import date, datetime
from collections import defaultdict, deque

WEIGHT_SETS = {
    "smart": {"importance":0.28,"urgency":0.22,"effort":0.18,"deadline":0.18,"blocker":0.14},
    "fastest":{"importance":0.15,"urgency":0.10,"effort":0.65,"deadline":0.05,"blocker":0.05},
    "impact":{"importance":0.70,"urgency":0.10,"effort":0.05,"deadline":0.05,"blocker":0.10},
    "deadline":{"importance":0.10,"urgency":0.70,"effort":0.05,"deadline":0.10,"blocker":0.05},
}

def days_until_due(due_date):
    if not due_date:
        return None
    return (due_date - date.today()).days

def normalize_importance(importance):
    return max(0.0, min(1.0, importance/10.0))

def normalize_effort(hours, cap=8.0):
    return 1.0 - min(hours / cap, 1.0)

def normalize_deadline(days, window=30):
    if days is None:
        return 0.0
    if days <= 0:
        return 1.0
    return max(0.0, (window - min(days, window)) / window)

def detect_cycles(tasks):
    g = {t['id']: set(t.get('dependencies', [])) for t in tasks}
    WHITE, GRAY, BLACK = 0,1,2
    color = {nid: WHITE for nid in g}
    cycles = []
    path = []
    def dfs(u):
        color[u] = GRAY
        path.append(u)
        for v in g.get(u, []):
            if v not in color: continue
            if color[v] == WHITE:
                dfs(v)
            elif color[v] == GRAY:
                try:
                    idx = path.index(v)
                    cycles.append(path[idx:] + [v])
                except ValueError:
                    cycles.append([v,u])
        path.pop()
        color[u] = BLACK
    for node in list(g.keys()):
        if color[node] == WHITE:
            dfs(node)
    return cycles

def compute_blocked_counts(tasks):
    inv = defaultdict(list)
    ids = set(t['id'] for t in tasks)
    for t in tasks:
        for dep in t.get('dependencies', []):
            if dep in ids:
                inv[dep].append(t['id'])
    blocked = {t['id']: 0 for t in tasks}
    for nid in blocked.keys():
        q = deque(inv.get(nid, []))
        seen = set()
        while q:
            cur = q.popleft()
            if cur in seen: continue
            seen.add(cur)
            blocked[nid] += 1
            for nxt in inv.get(cur, []):
                if nxt not in seen:
                    q.append(nxt)
    return blocked

def score_tasks(tasks, mode='smart'):
    sanitized = []
    for t in tasks:
        st = dict(t)
        st.setdefault('importance', 5)
        st.setdefault('estimated_hours', 1.0)
        st.setdefault('dependencies', [])
        st.setdefault('due_date', None)
        if isinstance(st['due_date'], str):
            try:
                st['due_date'] = datetime.strptime(st['due_date'], '%Y-%m-%d').date()
            except Exception:
                st['due_date'] = None
        sanitized.append(st)

    cycles = detect_cycles(sanitized)
    blocked_counts = compute_blocked_counts(sanitized)
    max_blocked = max(blocked_counts.values()) if blocked_counts else 1
    weights = WEIGHT_SETS.get(mode, WEIGHT_SETS['smart'])
    scored = []
    for t in sanitized:
        imp_n = normalize_importance(t['importance'])
        days = days_until_due(t['due_date']) if t['due_date'] else None
        urg_n = normalize_deadline(days)
        eff_n = normalize_effort(t['estimated_hours'])
        blocked_n = blocked_counts.get(t['id'], 0) / max(1, max_blocked)
        dependency_penalty = 1.0 / (1.0 + len(t.get('dependencies', [])))
        raw = (weights['importance'] * imp_n +
               weights['urgency'] * urg_n +
               weights['effort'] * eff_n +
               weights['deadline'] * urg_n)
        blocker_bonus = weights.get('blocker', 0.0) * blocked_n
        score = (raw * dependency_penalty) + blocker_bonus
        scaled = round(max(0.0, min(1.0, score)) * 100, 2)
        reason = {"importance_n": round(imp_n,3), "urgency_n": round(urg_n,3), "effort_n": round(eff_n,3),
                  "blocked_n": round(blocked_n,3), "dependency_count": len(t.get('dependencies',[]))}
        t_out = dict(t)
        t_out.update({"priority_score": scaled, "score_reason": reason})
        scored.append(t_out)
    cyclic_task_ids = set(i for c in cycles for i in c)
    non_cyclic = [t for t in scored if t['id'] not in cyclic_task_ids]
    non_cyclic.sort(key=lambda x: x['priority_score'], reverse=True)
    cyclic = [t for t in scored if t['id'] in cyclic_task_ids]
    return {"tasks_sorted": non_cyclic, "cycles": cycles, "cyclic_tasks": cyclic}
